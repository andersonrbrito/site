---
name: design-md-template
description: Modelo de design.md (manual de estética) para perfis e marcas que editam vídeo com IA. Use quando o usuário quiser criar ou atualizar o manual de estética do seu conteúdo.
---

# Modelo de design.md

Copie para a raiz da pasta de edição como `design.md` e preencha.

```markdown
# <Perfil/Marca> — Manual de estética

## Identidade
- Sobre o que é o conteúdo, tom de voz, público.

## Cores
| Uso | Hex |
|---|---|
| Fundo | #...... |
| Texto | #...... |
| Destaque principal | #...... |
| Destaque secundário | #...... |

## Tipografia
- Fonte principal (arquivo ou link), pesos para título, destaque e legenda.

## Layout
- 9:16 1080x1920: margem segura, texto até ~840px, nada nos 220px de cima e 300px de baixo.
- Destaques de 1 a 3 palavras, nunca cortados.

## Movimento e som
- Estilo de animação (pop, slide, zoom), ritmo dos cortes.
- SFX: onde usar. Trilha: estilos permitidos e proibidos. Voz sempre acima da trilha.

## Referências
- Vídeos, perfis e prints que representam o estilo.

## Proibido
- O que nunca deve aparecer.
```
