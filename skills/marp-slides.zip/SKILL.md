---
name: marp-slides
description: Atalho para a skill marp-slides (decks em Markdown com gráficos SVG). Use quando o usuário pedir slides, apresentação ou deck.
---

# MARP Slides

Skill criada por robonuggets: https://github.com/robonuggets/marp-slides

## Instalar
```bash
git clone https://github.com/robonuggets/marp-slides ~/.claude/skills/marp-slides
```

## Uso rápido
- Escreva os slides em Markdown separados por `---`.
- Exporte: `npx @marp-team/marp-cli slides.md --pdf --allow-local-files`
