---
name: vidiq-youtube-data
description: Como conectar o vidIQ ao Claude (conector MCP) para pesquisar palavras-chave, títulos, outliers e tendências do YouTube. Use quando o usuário quiser pesquisar pauta ou títulos de vídeo.
---

# vidIQ no Claude (conector MCP)

Isto não é um arquivo para instalar: é um conector. Página oficial: https://vidiq.com/pt/claude/

## Conectar
1. Abra a página oficial e siga o passo a passo para adicionar o conector na sua conta do Claude.
2. Autorize com a sua conta do vidIQ.

## Ideias de uso
- "Quais vídeos sobre edição com IA estão performando acima da média neste mês?"
- "Me dê 10 títulos com alto CTR para um vídeo sobre Claude Code."
