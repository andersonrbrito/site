---
name: editar-com-ia
description: Método do Anderson Brito para editar vídeos com IA no Claude Code. Use quando o usuário pedir para editar, cortar, legendar ou montar um vídeo a partir de um bruto, ou para criar o manual de estética (design.md) de um perfil.
---

# Editar com IA (método @andersonbrito.mp4)

## Antes de editar
1. Trabalhe sempre na pasta de edição do usuário. Leia `design.md` (estética) e `edicao.md` (briefing e feedback acumulado) se existirem. Se não existirem, ofereça criar a partir de fontes, cores, referências e prints que o usuário jogar na pasta.
2. Confira as ferramentas: `ffmpeg`, `ffprobe`, Python 3 e um transcritor (faster-whisper ou similar). Instale o que faltar e explique o que instalou.
3. Para animações em código, use Remotion (`npx create-video@latest`).

## Briefing (pergunte o que faltar)
- Objetivo do vídeo e CTA
- Cortes: muitos ou poucos; remover erros, repetições e silêncios
- Música e efeitos sonoros: sim ou não, intensidade
- Textos em tela, legendas, gráficos, imagens da internet, vídeos citados
- Nível de edição: leve, médio ou pesado
- Formatos: 9:16 (Reels/TikTok/Shorts) e/ou 16:9 (YouTube/LinkedIn/X)

## Execução
1. Transcreva com timestamps por palavra.
2. Proponha o corte em texto (o que sai e o que fica) e confirme.
3. Monte: cortes, b-roll, textos de 1 a 3 palavras, legenda, SFX nas entradas, trilha baixa sob a voz (voz sempre bem acima).
4. 9:16: texto até ~840px de largura em 1080, nada nos 220px de cima e 300px de baixo.
5. Renderize uma prévia e peça feedback como de um editor de verdade.

## Depois do feedback
Salve cada correção em `edicao.md`, seção "Feedback acumulado". O próximo vídeo deve nascer com essas regras.
