---
name: awesome-design-md
description: Referência de design. Coleção open source (MIT) de DESIGN.md extraídos de sites de produto. Use quando o usuário quiser gerar páginas, painéis ou artes no estilo de um site conhecido.
---

# Awesome DESIGN.md (VoltAgent, MIT)

Repositório: https://github.com/VoltAgent/awesome-design-md

## Como usar
1. Abra o repositório e escolha o estilo mais próximo do que você quer.
2. Copie o DESIGN.md dele para a pasta do projeto.
3. Peça para a IA criar a página ou a arte seguindo esse arquivo, trocando cores e fontes pelas da sua marca (seu design.md).
