---
name: refero-styles
description: Referência de design. Catálogo de estilos de sites reais no formato DESIGN.md (Refero). Use para buscar inspiração de identidade visual antes de criar UI, landing pages ou thumbnails.
---

# Refero Styles

Site: https://styles.refero.design/

## Como usar
1. Busque um estilo pelo nome do site ou pela categoria.
2. Copie o DESIGN.md do estilo.
3. Cole na pasta do projeto e peça para a IA gerar a interface seguindo esse arquivo, adaptando para a sua marca.
