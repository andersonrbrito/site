---
name: remotion
description: Atalho para as skills oficiais do Remotion (vídeos e motion graphics em React). Use quando o usuário quiser criar animações, legendas ou vídeos com código.
---

# Remotion (skills oficiais)

Criadas e mantidas pela equipe do Remotion: https://github.com/remotion-dev/skills

## Instalar a versão completa
```bash
npx skills add remotion-dev/skills
```
Ou clone o repositório e copie as pastas de `skills/` para `~/.claude/skills/`.

## Uso rápido
- Novo projeto: `npx create-video@latest`
- Prévia: `npx remotion studio`
- Render: `npx remotion render`

Verifique a licença do Remotion antes de uso comercial em empresas: https://www.remotion.dev/license
